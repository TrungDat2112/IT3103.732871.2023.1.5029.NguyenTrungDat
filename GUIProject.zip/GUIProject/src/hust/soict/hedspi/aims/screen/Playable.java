package hust.soict.hedspi.aims.screen;

public interface Playable {
	public void play();
}
